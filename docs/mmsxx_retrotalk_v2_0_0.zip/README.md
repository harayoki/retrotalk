# RetroTalk v2

## 同梱ファイル

- `RetroTalk_v2_0_0.js` — エンジン本体
- `index.html` — 最小の使用例
- `LICENSE` — 利用条件

## 初期化

スクリプトを読み込むと、グローバルに `MmsxxRetroTalk` が定義される。

```html
<script src="RetroTalk_v2_0_0.js"></script>
<script>
  const voice = new MmsxxRetroTalk();
  document.getElementById('say').onclick = () => voice.talk('コンニチワ');
</script>
```

ブラウザの制限により、音声はユーザーが画面を操作したあとでないと再生されない。

## API

```js
/**
 * テキストをその場で再生する。登録しないため、生成した波形は保持しない。
 * @param {string} text カタカナ。ひらがなも受け付ける
 * @param {object} [opts] 声の設定
 * @param {number} [priority=0] 値が大きいほど優先される。
 *   同時再生数を超えた場合は、優先度の低いものが停止する
 * @returns {number|undefined} 再生 ID。再生できなかった場合は undefined
 */
talk(text, opts, priority)

/**
 * テキストに名前を付けて登録する。再生はしない。
 * 同じ名前で 2 回目以降を再生するとき、波形は再生成されない。
 * @param {string} name 登録名
 * @param {string} text カタカナ
 * @param {object} [opts] 声の設定
 * @returns {void}
 */
defineTalk(name, text, opts)

/**
 * 登録済みのテキストを再生する。
 * @param {string|string[]} name 配列で渡すと、すべての波形を生成してから連続して再生する
 * @param {number} [priority=0] `talk` と同じ
 * @param {{gain?: number, rate?: number}} [opts] gain は音量の倍率、rate は再生速度
 * @returns {number|number[]|undefined} 再生 ID。配列で渡した場合は配列で返る
 */
playTalk(name, priority, opts)

/**
 * 波形の生成だけを行う。再生はしない。
 * `playTalk` は初回に波形を生成するため、その分だけ再生の開始が遅れる。
 * 複数を重ねて再生する場合は、あらかじめここで生成しておく。
 * @param {string|string[]} name 登録名。まとめて渡せる
 * @returns {void}
 */
prepareTalk(name)

/**
 * 再生中のものを停止する。
 * @param {string|number} [what] 登録名、または `playTalk` の戻り値。
 *   省略した場合はすべて停止する
 * @returns {void}
 */
stopTalk(what)

/**
 * 保持している波形を破棄する。再生中のものは最後まで再生される。
 * @param {string|string[]} [name] 登録名。省略した場合はすべて破棄する
 * @returns {void}
 */
forgetTalk(name)

/**
 * 読み上げできない文字を検査する。再生はしない。
 * @param {string} text 検査するテキスト
 * @returns {{ok: boolean, kana: number,
 *            unknown: Array<{ch: string, at: number, kind: string}>}}
 *   ok は読めない文字が無ければ true、kana は読めた文字数、
 *   at はテキスト内の位置、kind は文字の種別
 */
checkTalk(text)

/**
 * 波形を生成して返す。再生はしない。ファイルへ書き出す場合に使う。
 * @param {string} text カタカナ
 * @param {object} [opts] 声の設定
 * @returns {{rate: number, data: Float32Array, frames: number}}
 *   rate は 9940 固定、data は -1 から 1 の値、frames は 10ms 単位のフレーム数
 */
renderTalk(text, opts)

/** @type {number} 同時に再生できる数。既定値は 1 */
maxTalk
```

## opts に指定できるもの

`pitch` `speed` `formantShift` `bandShift` `breath` `jitter` `ring`
`style` `sing` `gain` `interp` `bits` `unknown`

オプションの詳細はマニュアルページを参照してください。

---

MMSXX sound engine 0.15.0 / RetroTalk v2.0.0
