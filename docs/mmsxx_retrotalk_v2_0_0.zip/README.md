# RetroTalk v2.0.0

カタカナを渡すと、80 年代のパソコンのような声でしゃべります。
録音は持たず、鳴らすたびにその場で波形を作ります。
外から何も読み込みません。このファイルだけで動きます。

## 同梱ファイル

- `RetroTalk_v2_0_0.js` — エンジン本体
- `index.html` — 最小の使用例
- `LICENSE` — 利用条件

## 鳴らすまで

読み込むと `MmsxxRetroTalk` が定義されます。

```html
<script src="RetroTalk_v2_0_0.js"></script>
<script>
  const voice = new MmsxxRetroTalk();
  document.getElementById('say').onclick = () => voice.talk('コンニチワ');
</script>
```

音が出るのは、画面が一度操作されてからです。ブラウザがそう決めています。
`talk()` と `playTalk()` は中でその手続きをするので、呼ぶ側では何もしません。

鳴っている途中でもう一度呼ぶと、前のものは止まって新しいほうが鳴ります。
先に `stopTalk()` を呼ぶ必要はありません。重ねたいときは `maxTalk` を増やします。

## 生えるもの

読み込むと、次の 3 つが増えます。

```js
MmsxxRetroTalk        // 上のクラス
MMSXX.sound.RetroTalk // 同じもの。名前空間からも取れます
renderTalk            // 波形だけ作る関数。鳴らしません
```

`MMSXX` は入れ物です。同じ名前空間に別のものが入っていても、`MMSXX.sound` を
上書きせずに足します。ただし MMS/XX のサウンドエンジンがすでにいるページでは、
`new MmsxxRetroTalk()` が例外を投げます。あちらの `talk()` を使ってください。

## 文の書き方

カタカナで書きます。ひらがなも読みます。漢字は読めず、その字は落ちます。

- 空白と `、` は短い間、`。` `！` `？` は長い間になります
- `！` `？` `！？` は語尾の言い方が変わります
- `（ ）` でくくると、そこをひとまとまりとして持ち上げます
- `＞` `＜` はそこから抑揚を半音ずつ上げ下げします。句読点で戻ります
- `…` は上がらずに下がりきって弱くなります
- `ー` は伸ばし、`〜` は揺らしながら伸ばします

`@` で始まる指示を混ぜると、そこから後ろに効きます。指示は長さを持ちません。

```js
voice.talk('ワタシデス。@p180 イエ、ワタシデス。');
```

| | |
| --- | --- |
| `@p<Hz>` | 声の高さ。例 `@p200` |
| `@s<%>` | 話す速さ。例 `@s150`(1.5 倍) |
| `@v<0-15>` | 音量。例 `@v8` |

## API

```js
/**
 * テキストをその場で再生する。
 *
 * `defineTalk()` と `playTalk()` をまとめて行う短い書き方。
 *
 * ```js
 * voice.talk('コンニチワ');
 * ```
 *
 * 登録を残さないため、生成した波形は保持しない。
 * 同じテキストを再び渡すと、そのつど生成し直す。
 *
 * 波形を保持したい、停止したい、あらかじめ生成しておきたい。
 * このいずれかであれば `defineTalk()` で名前を付ける。
 *
 * @param {string} text カタカナ。`defineTalk()` と同じ
 * @param {object} [opts] 声の設定。`defineTalk()` と同じ
 * @param {number} [priority=0] `playTalk()` と同じ
 * @returns {number|undefined} 再生 ID。再生できなかった場合は undefined
 */
talk(text, opts, priority)

/**
 * テキストに名前を付けて登録する。ここでは再生しない。
 *
 * 録音データは持たない。カタカナ(ひらがなも可)を渡すと、再生時に
 * フォルマント合成で波形を生成する。生成した波形は名前ごとに保持するため、
 * 2 回目以降は生成し直さない。
 *
 * テキストには、MML と同じ `@` の書き方で指示を混ぜられる。
 * 指示はそこから後ろに効き、指示そのものは長さを持たない。
 *
 *   `@p<Hz>`  声の高さ。例 `@p200`
 *   `@s<%>`   話す速さ。例 `@s150`(1.5 倍)
 *
 *   voice.defineTalk('two', 'ワタシデス。@p180 イエ、ワタシデス。');
 *
 * 抑揚は句読点(`、` `。`)でリセットされる。実機は「少し上がってだんだん下がる」
 * 動きを文全体に適用するため、切れ目が無いと長い文の終わりで音が沈む。
 * 空白ではリセットされない。区切りではなく間として扱う。
 *
 * @param {string} name 登録名
 * @param {string} text カタカナ。空白と句読点は間になる
 * @param {object} [opts] 声の設定。名前の一覧は下の「opts に指定できるもの」
 * @returns {void}
 */
defineTalk(name, text, opts)

/**
 * 登録済みのテキストを再生する。
 *
 * @param {string|string[]} name `defineTalk()` で登録した名前。
 *   配列を渡すと、すべての波形を生成してから連続して再生する
 * @param {number} [priority=0] 値が大きいほど優先される
 * @param {{gain?: number, rate?: number}} [opts]
 *   gain は音量の倍率、rate は再生速度(1 より大きいと速く高くなる)
 * @returns {number|number[]|undefined} 再生 ID。配列を渡した場合は配列。
 *   再生できなかった場合は undefined
 */
playTalk(name, priority, opts)

/**
 * 波形の生成だけを行う。再生はしない。
 *
 * `playTalk()` は初回に波形を生成するため、その分だけ再生の開始が遅れる。
 * 複数を重ねて再生するとき、この遅れはずれになる。2 人ぶんを続けて
 * `playTalk()` すると、2 人目は 1 人目の生成が終わってから始まる。
 * あらかじめ両方を生成しておけば、ずれずに重なる。
 *
 * @param {string|string[]} name `defineTalk()` で登録した名前。まとめて渡せる
 * @returns {void}
 */
prepareTalk(name)

/**
 * 再生中のものを停止する。
 *
 * @param {string|number} [what] 登録名、または `playTalk()` の戻り値。
 *   省略した場合はすべて停止する
 * @returns {void}
 */
stopTalk(what)

/**
 * 保持している波形を破棄する。
 *
 * `defineTalk()` は名前ごとに波形を持ち続ける。2 回目以降を生成し直さずに
 * 済ませるためだが、その分メモリを使う。使わなくなったものは破棄できる。
 *
 * ```js
 * voice.forgetTalk('hello');              // 名前を指定して破棄
 * voice.forgetTalk(['demo1', 'demo2']);   // まとめて破棄
 * voice.forgetTalk();                     // 全て破棄
 * ```
 *
 * 再生中のものは最後まで再生される。波形は再生側が参照している。
 *
 * @param {string|string[]} [name] 登録名。省略した場合はすべて破棄する
 * @returns {void}
 */
forgetTalk(name)

/**
 * 読み上げられない文字を検査する。再生はしない。
 *
 * 登録する前に確かめるときに使う。読めない文字が、テキストのどこにあるかまで返る。
 *
 * ```js
 * const got = voice.checkTalk('今日は 3ガツ デス');
 * // { ok: false, kana: 6, unknown: [{ ch: '今', at: 0, kind: 'kanji' }, ...] }
 * ```
 *
 * @param {string} text 検査するテキスト
 * @returns {{ok: boolean, kana: number,
 *            unknown: Array<{ch: string, at: number, kind: string}>}}
 *   ok は読めない文字が無ければ true、kana は読めた文字数、
 *   at はテキスト内の位置、kind は文字の種別
 */
checkTalk(text)

/**
 * テキストから波形を生成して返す。再生はしない。
 *
 * @param {string} text カタカナ(ひらがなも可)
 * @param {object} [opts] 声の設定
 * @returns {{rate:number, data:Float32Array, frames:number}}
 */
renderTalk(text, opts)

/**
 * 同時に再生できるセリフの数。
 *
 * 重なると聞き取れないため、既定は 1 つ。
 * 複数の人物が同時に話す場面では増やす。
 *
 * @type {number}
 */
maxTalk
```

```js
/** @type {number} 同時に再生できる数。既定値は 1 */
maxTalk
```

## opts に指定できるもの

`pitch` `speed` `fall` `rise` `formantShift` `bandShift` `breath` `jitter`
`ring` `interp` `bits` `frame` `style` `gain` `level`

どれがどう効くかは、つまみを動かしながらマニュアルページで聞けます。

---

MMSXX sound engine 0.15.0 / RetroTalk v2.0.0
